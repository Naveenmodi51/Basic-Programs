//Method to return Sum of Odd numbers within 'n'

import java.util.Scanner;
class MainOddNumber
{
static int getOddNumbers(int n)
{ 
int sum=0, i=1;
do{
if(i%2!=0)
sum=sum+i;
i++;
} while (i<=n);
return sum;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the Range");
int x=sc.nextInt();
int r= getOddNumbers(x);
System.out.println("sum of Odd numbers within "+x+" is "+r);
}
}