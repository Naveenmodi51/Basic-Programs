//Method to Sum of there Devices

import java.util.Scanner;
class MainSumDevices
{
static int SumofDevices(int n)
{
int sum=n, i=1;
while (i<=n/2)
{
if (n%i==0)
sum=sum+i;
i++;
}
return sum;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the integer value");
int x=sc.nextInt();
int s=SumofDevices(x);
System.out.println("Sum of Devices for " +x+" is " +s);

}
}