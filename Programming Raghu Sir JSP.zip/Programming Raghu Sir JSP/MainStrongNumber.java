import java.util.Scanner;
class MainStrongNumber
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number");
int n =sc.nextInt();
Strong s=new Strong();
boolean rs=s.getStrongNumber(n);
if (rs==true)
System.out.println(n+" is Strong Number");
else 
System.out.println(n+" is Strong Number");
}
}