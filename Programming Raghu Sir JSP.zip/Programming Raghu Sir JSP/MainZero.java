import java.util.Scanner;
class MainZero
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number");
int n=sc.nextInt();
if(n==0)
System.out.println(n+ " is Zero");
else
System.out.println(n+ " is not Zero");
}
}
