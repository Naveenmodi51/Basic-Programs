// to check user entered number is even or odd(5th method)using arrays
import java.util.Scanner;
class MainEO5
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the number");
int n=sc.nextInt();

String st[]= {"even", "odd"};
System.out.println(n+"is"+st[n%2]);

  
}
}