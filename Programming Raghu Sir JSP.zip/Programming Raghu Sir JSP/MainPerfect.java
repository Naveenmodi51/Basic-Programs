//Method to return true if the number is Perfect number

import java.util.Scanner;
class MainPerfect
{
static boolean isPerfectNumber(int n)
{
int sum=0, i=1;
while (i<=n/2)
{
if (n%i==0)
sum=sum+i;
i++;
}
return sum==n;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the integer value");
int x=sc.nextInt();
boolean rs=isPerfectNumber(x);
if(rs==true)
System.out.println(x+" is Perfect number");
else
System.out.println(x+" is not Perfect number");
}
}