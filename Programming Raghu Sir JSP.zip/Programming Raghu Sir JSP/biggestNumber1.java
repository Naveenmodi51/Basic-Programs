//Method to Return Biggest among three number

import java.util.Scanner
class biggestNumber1
{
int getbN(int a, int b, int c,)
{
if(a>b && A>c)

else(b>c)
}
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter the numbers");

int a=sc.nextInt();

int b=sc.nextInt();

int c=sc.nextInt();

biggestNumber1 bN=new biggestNumber1();
System.out.println(c+" is Biggest number");
int a=bN.getbN(a)
System.out.println(b+" is Biggest number");
int a=bN.getbN(b)
System.out.println(a+" is Biggest number");
int a=bN.getbN(c)
}
}


