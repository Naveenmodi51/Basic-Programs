class Pen{
int price;
String type;
Pen(){
 
}
Pen(int p,String ty){
price=p;
type=ty;
}
public static void main(String args[]){
Pen p=new Pen(45, "RedPen");
System.out.println(p.price +" "+ p.type);
}
}
