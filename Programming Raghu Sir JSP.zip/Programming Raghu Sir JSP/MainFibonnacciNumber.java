//Print first 'n' fibonnacci number

import java.util.Scanner;
class MainFibonnacciNumber
{
static int getFibonnacciNumber(int n)
{
int f1=0, f2=1;
while (n>1)
{
System.out.println(f1+"");
 f3=f1+f2;
f1=f2;
f2=f3;
n--;
}

}
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
System.out.println("enter the value of n");
int n=sc.nextInt();
int f=getFibonnacciNumber(n);
System.out.println(n+" Fibannocci number 'n' is " +f);
}
}