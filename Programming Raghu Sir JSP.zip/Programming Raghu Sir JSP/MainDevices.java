//Method to How many devices are therefore 'n'

import java.util.Scanner;
class MainDevices
{
static int CountDevices(int n)
{
int count=1, i=1;
while (i<=n/2)
{
if (n%i==0)
count ++;
i++;
}
return count;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the integer value");
int x=sc.nextInt();
int dc=CountDevices(x);
System.out.println("Number of Devices for " +x+" is"+dc);

}
}