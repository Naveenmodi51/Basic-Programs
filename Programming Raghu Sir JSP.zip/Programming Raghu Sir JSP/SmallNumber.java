//Smallest among three numbers

import java.util.Scanner;
class SmallNumber
{
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the numbers");
int a=sc.nextInt();
int b=sc.nextInt();
int c=sc.nextInt();

if(a<b && a<c)
System.out.println(a+" is Small number");
else if(b<c)
System.out.println(b+" is small number");
else 
System.out.println(c+ " is small number");
}
} 
