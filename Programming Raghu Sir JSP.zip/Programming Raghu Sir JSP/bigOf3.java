import java.util.Scanner;
class bigOf3
{
int getRes(int x, int y, int z)
{
if(x>y && x>z)
return x;
else if(y>z)
return y;
else
return z;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter any three numbers");
int x=sc.nextInt();
int y=sc.nextInt();
int z=sc.nextInt();
bigOf3 bg =new bigOf3();
int n=bg.getRes(x,y,z);
System.out.println("the biggest number is " +n);
}
}