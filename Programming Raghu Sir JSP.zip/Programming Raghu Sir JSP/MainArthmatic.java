import java.util.Scanner;
class MainArthmatic
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter any two integer values");
int x=sc.nextInt();
int y=sc.nextInt();
System.out.println(x+"+"+y+"="+(x+y));
System.out.println(x+"-"+y+"="+(x-y));
System.out.println(x+"*"+y+"="+(x*y));
System.out.println(x+"/"+y+"="+(x/y));
System.out.println(x+"%"+y+"="+(x%y));
}
}