class Bike{
 String model="Ninja";
 int price=630000;
 public Static void main( String []args){
 Bike b=new Bike();
 system.out.println(b.model,b.price)
}
}