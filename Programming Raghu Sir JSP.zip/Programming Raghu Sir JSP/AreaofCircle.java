//Method to Area of Circle

import java.util.Scanner;
class AreaofCircle
{
 double getAc(double r)
{
double sum=3.142*r*r;
return sum;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter Radius of circle");
double r=sc.nextDouble();

AreaofCircle ac=new AreaofCircle();
double n=ac.getAc(r);
System.out.println("Area of Circle is " +n);
}
}
