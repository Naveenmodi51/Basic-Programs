//Multiple of 3 or not

import java.util.Scanner;
class Multipleof3
{
	public static void main (String args[])
	{
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter the number");
	int n=sc.nextInt();
	
	if (n%3==0)
	System.out.println(n + " is multiple of 3 ");
	else
	System.out.println(n+" is not a multiple of 3");
	}
}