//Method to return the How many digits in a number

import java.util.Scanner;
class MainDigitNumber
{
static int CountDigit(int n)
{
int count=0;
do{
n=n/10;
count ++;
}while(n!=0);
return count;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the integer value");
int x=sc.nextInt();
int cd=CountDigit(x);
System.out.println("Number of Digit in " +x+" is " +cd);

}
}