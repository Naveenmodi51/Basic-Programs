//Return method to a fibonnacci number

import java.util.Scanner;
class MainFibonnacci
{
static int getFibonnacciNumber(int n)
{
int f1=0, f2=1;
int f3=0;
while (n>0)
{
 f3=f1+f2;
f1=f2;
f2=f3;
n--;
}
return f3-1;
}
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
System.out.println("enter the value of n");
int n=sc.nextInt();
int f=getFibonnacciNumber(n);
System.out.println(n+" Fibannocci number 'n' is " +f);
}
}