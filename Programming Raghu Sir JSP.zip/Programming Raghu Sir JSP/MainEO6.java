// to check user entered number is even or odd(6th method) without using arthmatic operation
import java.util.Scanner;
class MainEO6

{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the number");
int n=sc.nextInt();

if((n&1)==0)

System.out.println(n+"is even");
else
System.out.println(n+"is odd");

  
}
}