class Car{
String model="Audi Q7";
String clr="White";
int price=7200000;
public static void main (String args[]){
Car c=new Car();
System.out.println(c.model+" "+c.clr+" "+c.price);
}
}
