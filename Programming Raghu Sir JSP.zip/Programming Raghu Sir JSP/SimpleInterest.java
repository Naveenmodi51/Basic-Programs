//Method to Simple Interest

import java.util.Scanner;
class SimpleInterest
{
 int getSi(int p, int t, int r)
{
int sum=p*t*r/100;
return sum;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter Principle amount");
int p=sc.nextInt();
System.out.println("enter Time");
int t=sc.nextInt();
System.out.println("enter Rate of interest");
int r=sc.nextInt();

SimpleInterest si=new SimpleInterest();
int n=si.getSi(p,t,r);
System.out.println("Simple interest is " +n);
}
}
