import java.util.Scanner;
class Details
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("What is your name?");
String name=sc.next();
System.out.println(name+"How old are you?");
int age =sc.nextInt();
System.out.println("enter your mobile number");
long mobilenumber=sc.nextLong();
System.out.println("enter the city name");
String city=sc.next();
System.out.println("name:"+name);
System.out.println("age:"+age);
System.out.println("mobilenumber:"+mobilenumber);
System.out.println("city:"+city);
}
}