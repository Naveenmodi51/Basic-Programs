//Method to return Sum of Even numbers within 'n'

import java.util.Scanner;
class MainEvenNumber
{
static int getEvenNumbers(int n)
{ 
int sum=0, i=1;
do{
if(i%2==0)
sum=sum+i;
i++;
} while (i<=n);
return sum;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the Range");
int x=sc.nextInt();
int r= getEvenNumbers(x);
System.out.println("sum of Even numbers within "+x+" is "+r);
}
}