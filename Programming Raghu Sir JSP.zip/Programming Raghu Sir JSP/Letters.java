//Print character is capital letter, small letter, digit or Special letter

import java.util.Scanner;
class Letters
{
public static void main(String args [])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a letter");
char ch=sc.next().charAt(0);

if (ch>='A' && ch<='Z')
System.out.println(ch+" is a Capital letter");
else if (ch>='a' && ch<='z')
System.out.println(ch+" is a Small letter");
else if (ch>='0' && ch<='9')
System.out.println(ch+" is a digit");
else
System.out.println(ch+" is a Special letter");
}

}
