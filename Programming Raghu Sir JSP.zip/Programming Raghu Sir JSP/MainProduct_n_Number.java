//Method to return Product of first 'n' numbers

import java.util.Scanner;
class MainProduct_n_Number
{
static int getProductNumbers(int n)
{ 
int pro=1, i=1;
do{
pro=pro*i;
i++;
} while (i<=n);
return pro;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the Range");
int x=sc.nextInt();
int r= getProductNumbers(x);
System.out.println("Product of "+x+" numbers is "+r);
}
}