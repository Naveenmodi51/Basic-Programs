//Product of number

import java.util.Scanner;

class ProductNumber
{

static int getProductofNum(int []x)
{
int pro=1;
for(int i=0; i<x.length; i++)
{
   pro=pro*x[i];	
}
return pro;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the size of an array");
int n =sc.nextInt();
int ar[]=new int[n];
System.out.println("enter "+n+" value");
for(int i=0; i<n; i++)
{
ar[i]=sc.nextInt();
}
System.out.println("product of number "+ getProductofNum(ar));
}
}

