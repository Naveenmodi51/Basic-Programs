//Biggest Number

import java.util.Scanner;
class BiggArray
{
static int biggestNumber(int n[])
{ 
int big=n[0];
for (int i=0; i<n.length; i++)
{
if(n[i]>big)
big=n[i];
}
return big;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the size of an array");
int n=sc.nextInt();
int ar[]=new int[n];
System.out.println("enter "+n+" value");
for(int i=0; i<n; i++)
{
ar[i]=sc.nextInt();
}
System.out.println("Biggest Number iS "+biggestNumber(ar));
}
}