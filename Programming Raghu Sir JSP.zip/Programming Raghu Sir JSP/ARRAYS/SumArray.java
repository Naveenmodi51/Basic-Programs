class SumArray
{
static int sumofArray(int a[])
{ int sum=0;
for (int i=0; i<a.length; i++)
{
sum=sum+a[i];
}
return sum;
}
public static void main(String args[])
{
int ar[]={25,45,32,28,17};
int s=sumofArray(ar);

System.out.println("sum is " +s);
}
}