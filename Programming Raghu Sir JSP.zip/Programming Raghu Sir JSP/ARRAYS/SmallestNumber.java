//Smallest number

import java.util.Scanner;

class SmallestNumber
{

static int getSmallestNum(int []x)
{
int small=x[0];
for(int i=1; i<x.length; i++)
{
	if(x[i]<small)
	small=x[i];
}
return small;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the size of an array");
int n =sc.nextInt();
int ar[]=new int[n];
System.out.println("enter "+n+" value");
for(int i=0; i<n; i++)
{
ar[i]=sc.nextInt();
}
System.out.println("Smallest number "+ getSmallestNum(ar));
}
}

