class MainArray
{
public static void main(String args[])
{
int ar[]={25,45,32,28,17};
int sum=0;
for (int i=0; i<ar.length; i++)
{
sum=sum+ar[i];
}
System.out.println("sum is " +sum);
}
}