//Smallest Number

import java.util.Scanner;
class SmallNumber
{
static int getSmallNumber(int ar[])
{
int small=a[0];
for(int i=0; i<ar.length; i++)
{
if(a[i]<small)
small=a[i];
}
return small;
}
public static void main(Strng args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the size of an array");
int a=sc.nextInt();
int ar[]=new int[a];
System.out.println("Enter "+a+" value");
for(int i=0; i<n; i++)
{
ar[i]=sc.nextInt();
}
System.out.println("Smallest Number "+ getSmallNumber(ar));
}
}
