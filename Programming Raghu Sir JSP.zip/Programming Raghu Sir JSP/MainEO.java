// to check user entered number is even or odd
import java.util.Scanner;
class MainEO
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the number");
int n=sc.nextInt();
if(n%2==0)
System.out.println(n+" is odd");
else
System.out.println(n+" is even");
}
}