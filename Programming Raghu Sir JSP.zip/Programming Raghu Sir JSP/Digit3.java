//method to Digit number

import java.util.Scanner;
class Digit3
{
boolean getOP(int n)
{
if (n>=-9 && n<=9)
return true;
else 
return false;
}
public static void main (String args[])
{
System.out.println("enter the number");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
Digit3 d=new Digit3();
boolean b=d.getOP(n);
System.out.println("Entered number is digit " +b);

}
}
