//Define a method to return true if the number is Happy number otherwise false

import java.util.Scanner;
class MainHappy
{
boolean  isHappyNumber(int n)
{
while (n>9)
{
int sum=0;
do{
int r= n%10;
sum=sum+r*r;
n=n/10;
}while (n!=0);
n=sum;
}
return n==1||n==7;
}
public static void main (String args[])
{
MainHappy mh=new MainHappy();
boolean br=mh.isHappyNumber(n);
if (br==true)
System.out.println("happy number");
else 
System.out.println("not happy number");
}
}