//Method to return the reverse of the number

import java.util.Scanner;
class MainReverseNumber
{
static int getReverseofNumbers(int n)
{ 
int rev=0;
do{
int r=n%10;
rev=rev*10+r;
n=n/10;
}while (n!=0);
return rev;
}
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the number");
int x=sc.nextInt();
int r= getReverseofNumbers(x);
System.out.println("Reverse of a number is "+r);
}
}