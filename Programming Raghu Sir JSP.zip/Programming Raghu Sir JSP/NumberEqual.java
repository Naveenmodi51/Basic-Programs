//TWo numbers are equal

import java.util.Scanner;
class EqualNumber
{
int x;
int y;

boolean EqualNumber(int x,int y)
{
if (x==y)
return true;
else 
return false;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number");
int x=sc.nextInt();
int y=sc.nextInt();
EqualNumber eq=new EqualNumber();

boolean b=eq.EqualNumber(x,y);

System.out.println(b+"Are equal numbers");
}
}


