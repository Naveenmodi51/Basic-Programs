//Print the Armstrongnumbers withn 1000

import java.util.Scanner;
class MainArmstrongNumbers1
{
public static void main (String args[])
{
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number");
int n=sc.nextInt();
MainArmstrongNumbers1 an=new MainArmstrongNumbers1();
int m=isArmstrong(n);
System.out.println("Armstrong numbers within 1000");
}
}

 