class AccountInfo{
String accname;
double balance;
String branch;
long pincode;
AccountInfo(String an, double bl, String br, long pin){
 accname=an;
 balance=bl;
 branch=br;
 pincode=pin;
}

public static void main (String args[]){
AccountInfo a=new AccountInfo("Guldu",65213.24,"Dharwad",580005);
System.out.println(a.accname+" "+a.balance+" "+a.branch+" "+a.pincode);
}

}
