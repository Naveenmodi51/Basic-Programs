class MainRunner2
{
public static void main (String args[])
{
Convertion cv =new Convertion();
System.out.println("Binary of 49 is"+cv.decToBin());
System.out.println("Octal of 49 is"+cv.decToOct());
System.out.println("Hexdecimal of 49 is"+cv.decToHex());
}
}
