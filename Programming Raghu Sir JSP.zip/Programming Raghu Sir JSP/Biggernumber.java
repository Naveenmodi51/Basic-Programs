//Biggest number amoung three numbers

import java.util.Scanner;
class Biggernumber 
{
	public static void main (String args[])

	{
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter three numbers");
	int x=sc.nextInt();
	int y=sc.nextInt();
	int z=sc.nextInt();
	if(x>y)
	{ 
	 if(x>z)
	 System.out.println(x +" is bigger number");
	 else
	 System.out.println(z+ " is bigger number");
	 else if(y>z)
	  System.out.println(y+ " is bigger number");
	 else
	  System.out.println(z+ " is bigger number");

	}
	}
}