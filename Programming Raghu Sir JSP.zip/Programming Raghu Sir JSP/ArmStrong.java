class ArmStrong
{
static boolean checkArmStrong(int n)
{
int sum=0, temp=n;
while(n!=0){
int rem=n%10;
int c=rem*rem*rem;
sum=sum+c;
n=n/10;
}
if(sum==temp)
return true;
else
return false;
}
public static void main (String args[])
{
for (int i=1; i<=1000; i++){
boolean result = checkArmStrong(i);
if(result)
System.out.println("Armstrong Number" +i);
}
}
}

