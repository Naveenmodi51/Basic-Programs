//Define a method to return true if the number is Special two digit number otherwise return false.

import java.util.Scanner;
class MainRunner
{
public static void main(String args [])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the Number ");
int n=sc.nextInt();

SpecialNumber sp = new SpecialNumber();
boolean rs=sp.isSpecialtwodigit(n);
if(rs==true)
System.out.println(rs+" is Special two digit number");
else 
System.out.println(rs+" is not Special two digit number");
}
}

