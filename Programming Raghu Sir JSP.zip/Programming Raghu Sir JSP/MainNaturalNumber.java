//Sum of n natural numbers

import java.util.Scanner;
class MainNaturalNumber
{
static int getNaturalNumbers(int r)
{
int sum=0, i=1;
do{
sum=sum+i;
i++;
}while(i<=r);
return sum;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the range");
int x=sc.nextInt();
int n= getNaturalNumbers(x);
System.out.println("sum of " +x+ " natural numbers is " +n);
}
}


