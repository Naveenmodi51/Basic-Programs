// to check user entered number is even or odd(2 method)
import java.util.Scanner;
class MainEO2
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the number");
int n=sc.nextInt();
if(n/2*2==n)
System.out.println(n+" is even");

else
System.out.println(n+" is odd");
}
}