import java.util.Scanner;
class MainRead
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter your age");
int age=sc.nextInt();
System.out.println("entered age:"+age);
}
}