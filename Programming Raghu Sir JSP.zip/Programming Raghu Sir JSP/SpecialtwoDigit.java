//Special two digit number.

import java.util.Scanner;
class SpecialtwoDigit
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter the number");
int n=sc.nextInt();

int d1=n/10;
int d2=n/10;
int sum=(d1+d2)+(d1*d2);
if (sum==n)


System.out.println(n+" is Special two digit number");
else
System.out.println(n+" is not Special two digit number");
System.out.println("Thank you");
}
}
