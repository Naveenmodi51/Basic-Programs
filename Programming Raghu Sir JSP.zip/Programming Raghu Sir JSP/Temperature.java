import java.util.Scanner;
class Temperature
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter the room temperature in celsius");
double temp=sc.nextDouble();

double f=temp*1.8+32;
System.out.println("temperature is in fahrenheit :" + f);
}
}