import java.util.Scanner;
class Square
{
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter side of a square");
int a=sc.nextInt();
System.out.println("Area of a square"+"="+(a*a));
System.out.println("Perimeter of a square"+"="+(4*a));
}
}
