import java.util.Scanner;
class Rectangle
{
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the lenth & breadth of the rectangle");
int l=sc.nextInt();
int b=sc.nextInt();
System.out.println("Area of a rectangle is"+"="+(l*b));
System.out.println("Area of a perimeter is"+"="+2*(l+b));
}
}