//Print middle value among those three number

import java.util.Scanner;
class MiddleNumber
{
public static void main(String args [])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter 3 numbers");
int x=sc.nextInt();
int y=sc.nextInt();
int z=sc.nextInt();

if (x>y && x<z|| x>z && x<y)
System.out.println(x +" is middle number");
else if (y>x && y<z|| y>z && y<x)
System.out.println(y+" is middle number");
else 
System.out.println(z+" is middle number");
}
}
