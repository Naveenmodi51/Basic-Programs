// to check user entered number is even or odd(4th method)
import java.util.Scanner;
class MainEO4
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the number");
int n=sc.nextInt();

String st=(n%2==0)? "even": "odd";
System.out.println(n+" is "+st);

  
}
}