//Method to Sum of its Digit

import java.util.Scanner;
class MainSumofDigit
{
static int SumofDigit(int n)
{
int sum=0;
do{
int r=n%10;
sum=sum+r;
n=n/10;
}while(n!=0);
return sum;
}
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the integer value");
int x=sc.nextInt();
int s=SumofDigit(x);
System.out.println("Sum of Digit in " +x+" is " +s);

}
}