//How many leap years within Year y

import java.util.Scanner;
class LeapYears
{
public static void main(String args [])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter Year");
int y=sc.nextInt();

int sum=y/400+y/4-y/100;
System.out.println("Number of Leapyears " +sum);


}

}
