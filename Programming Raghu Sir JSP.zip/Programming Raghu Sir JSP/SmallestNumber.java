//Smallest number among two numbers

import java.util.Scanner;
class SmallestNumber
{
	public static void main (String args[])
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter two distinct number");
	int a=sc.nextInt();
	int b=sc.nextInt();
	 
	if (a<b)
	
	System.out.println(a+ " is Smaller than "+b);
	else
	System.out.println(b+" is Smaller than "+a);
}
} 