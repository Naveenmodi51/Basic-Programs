import java.util.Scanner;
class StudentMarks
{
public static void main (String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter student 4 subject marks");
int a=sc.nextInt();
int b=sc.nextInt();
int c=sc.nextInt();
int d=sc.nextInt();

int sum=a+b+c+d;
double perc= (sum)/4;

System.out.println("Total marks scored is : "+sum);
System.out.println("Percentage is : "+ perc);
}
}

