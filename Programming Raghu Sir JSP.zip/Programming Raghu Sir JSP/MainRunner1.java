//Define a method to return true if the two numbers are equal otherwise return false.

import java.util.Scanner;
class MainRunner1
{


public static void main(String args [])
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter the Numbers ");
int n=sc.nextInt();

TwoNumbersEqual tw=new TwoNumbersEqual();
boolean rs=sp.isTwoNumberequal(n);
if(rs==true)
System.out.println(rs+" Two numbers are Equal");
else 
System.out.println(rs+" Two numbers are not Equal");
}
}

