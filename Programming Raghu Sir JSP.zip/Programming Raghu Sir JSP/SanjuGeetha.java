//Sanju weds Geetha

import java.util.Scanner;
class SanjuGeetha 
{
	public static void main (String args[])

	{
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter a number");
	int a=sc.nextInt();
	
	if(a%3==0 && a%5==0) 
	 System.out.println("Sanju weds Geetha");
	 else if(a%3==0)
	 System.out.println("Sanju");
	 else if(a%5==0)
	  System.out.println("Geetha");
	 else
	  System.out.println("Break up");

	
	}
}