class Student{
String name;
int Rno;
double perc;
Student(){
}
Student(double p){
perc=p;
}
Student(String n,int Rn){
name=n;
Rno=Rn;
}
public static void main (String args[]){
Student s1=new Student("Dinga",06);
System.out.println(s1.name+" "+s1.Rno);

Student s2=new Student(84.33);
System.out.println(s2.name+" "+s2.Rno+" "+s2.perc);
}
}