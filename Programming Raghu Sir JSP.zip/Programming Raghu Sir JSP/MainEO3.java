// to check user entered number is even or odd(3rd method)
import java.util.Scanner;
class MainEO3
{
public static void main(String args[])
{
Scanner sc =new Scanner(System.in);
System.out.println("enter the number");
int n=sc.nextInt();
switch(n%2)
{
 case 0: System.out.println(n+" is even");

         break;
case 1: System.out.println(n+" is odd");
}
}
}