class Literals {
 public static void main(String args[]){
 System.out.println(0b10101);
 System.out.println(076);
 System.out.println(891);
 System.out.println(0xa2);
}
}