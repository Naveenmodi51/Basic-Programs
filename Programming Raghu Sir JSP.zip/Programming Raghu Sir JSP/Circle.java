import java.util.Scanner;
class Circle
{
public static void main (String args[])
{
Scanner sc=new Scanner(System.in);
System.out.println("enter radius of a circle");
int r=sc.nextInt();
System.out.println("Area of the circle"+"="+(3.142*r*r));
System.out.println("Circumference"+"="+(2*3.142*r));
}
}
