//Two Numbers are Equal


class TwoNumbersEqual
{
boolean isTwoNumberEqual(int n)
{
int sum=n1==n2;
return sum==n;
}
}